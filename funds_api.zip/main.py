def lambda_handler(event, context):
    return {
        "statuscode": 200,
        "body": "Funds API Working Successfully"
    }