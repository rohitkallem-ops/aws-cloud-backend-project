def lambda_handler(event, context):
    return {
        "statuscode": 200,
        "body": "User Learning API Working Successfully"
    }
