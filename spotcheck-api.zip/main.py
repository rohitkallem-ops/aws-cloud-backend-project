def lambda_handler(event, context):
    return {
        "statuscode": 200,
        "body": "Spotcheck API Working Successfully"
    }
