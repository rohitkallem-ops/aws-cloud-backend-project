def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "MF Central API Working Successfully"
    }
