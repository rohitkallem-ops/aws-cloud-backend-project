def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Financial Plan PDF API Working Successfully"
    }
