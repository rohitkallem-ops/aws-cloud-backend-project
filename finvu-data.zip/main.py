def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Finvu Data API Working Successfully"
    }